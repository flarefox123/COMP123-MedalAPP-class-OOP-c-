﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MedalApp
{

    enum MedalColor
    {
        Bronze,
        Silver,
        Gold
    }

    class Medal
    {
        public string Name { get; }
        public string TheEvent { get; }
        public MedalColor Color { get; }
        public int Year { get; }
        public bool IsRecord { get; }

        //constructor
        public Medal(string name, 
            string theEvent, 
            MedalColor color, 
            int year, 
            bool isRecord)
        {
            Name = name;
            TheEvent = theEvent;
            Color = color;
            Year = year;
            IsRecord = isRecord;
        }

        public override string ToString()
        {
            return $"{Year} - {TheEvent}{(IsRecord ? "(R)" : "")} {Name}({Color})";
        }
    }
}
